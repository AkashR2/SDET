package sdetassignment_task1;

import java.util.Scanner;

public class PowerOfTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
int num[];
System.out.print("Enter the number of value:");
int d=sc.nextInt();
	num=new int[d];
for(int i=0;i<d;i++)
{
	num[i]=sc.nextInt();
}
System.out.print("Given value is power of 2:\n");
for(int n : num)
{
	if(Poweroftwo(n))
{
	System.out.println("YES");
}
else
{
	System.out.println("NO");
}
	}
	}

 private static boolean Poweroftwo(int n) {
	if(n%2!=0)
	{
		return false;
	}
	else
	{
		for(int i=0;i<=n;i++)
		{
			if(Math.pow(2,i)==n)
			{
				return true;
			}
		}
	}
		return false;
	
}
}



