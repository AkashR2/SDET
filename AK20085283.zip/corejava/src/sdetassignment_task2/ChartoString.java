package sdetassignment_task2;

import java.util.Arrays;
import java.util.Scanner;

public class ChartoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char c;
Scanner sc=new Scanner(System.in);
System.out.print("Enter the character to be converted:");
c=sc.next().charAt(0);
String s=Character.toString(c);
System.out.println("Converted String:"+s);
//Program for Character to string conversion
String s1;
Scanner sw=new Scanner(System.in);
System.out.print("Enter the character to be converted:");
 s1=sw.nextLine();
System.out.print("Converted character:");
char c1[]=s1.toCharArray();
System.out.print(Arrays.toString(c1));

	}

}
