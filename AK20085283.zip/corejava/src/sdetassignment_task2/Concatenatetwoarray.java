package sdetassignment_task2;

public class Concatenatetwoarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {3,7,13,25};
int b[]= {4,16,1,2,3,22};
int c[]=new int[a.length+b.length];
int count=0;
for(int i=0;i<a.length;i++)
{
	c[i]=a[i];
	count++;
}
for(int j=0;j<b.length;j++)
{
	c[count++]=b[j];
}
System.out.print("Concatenated Array:");
for(int i=0;i<c.length;i++)
{
		System.out.print(c[i]+" ");
}
	}

}
