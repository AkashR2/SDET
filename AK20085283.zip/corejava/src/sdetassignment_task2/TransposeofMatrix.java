package sdetassignment_task2;

import java.util.Scanner;

public class TransposeofMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		  int i, j, row, col;
		  System.out.println("Enter the number of rows:");
		  row = sc.nextInt();
		  System.out.println("Enter the number of columns:");
		  col = sc.nextInt();
		  int[][] mat = new int[row][col];
		  int[][] transpose = new int[col][row];
		  System.out.println("Enter the elements of the matrix");
		  for (i = 0; i < row; i++) {
		   for (j = 0; j < col; j++) {
		    mat[i][j] = sc.nextInt();
		   }
		  }
		  System.out.println("The elements of the matrix");
		  for (i = 0; i < row; i++) {
		   for (j = 0; j < col; j++) {
		    System.out.print(mat[i][j] + "\t");
		   }
		   System.out.println("");
		  }
		  //To find transpose
		  for (i = 0; i < row; i++) {
		   for (j = 0; j < col; j++) {
		    transpose[j][i] = mat[i][j];
		   }
		  }
		  System.out.println("The transpose of the matrix is :- ");
		  for (i = 0; i < col; i++) {
		   for (j = 0; j < row; j++) {
		    System.out.print(transpose[i][j] + "\t");
		   }
		   System.out.println("");
		  }
		 }
		}