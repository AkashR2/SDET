package sdetassignment_task2;

import java.util.Scanner;

public class removewhitespaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s;
Scanner sc=new Scanner(System.in);
System.out.print("Enter the sentence:");
s=sc.nextLine();
s=s.replaceAll("\\s","");
System.out.println("After replacing whitespaces:"+s);		
	}
}
